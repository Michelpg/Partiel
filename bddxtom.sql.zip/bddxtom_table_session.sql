
-- --------------------------------------------------------

--
-- Structure de la table `session`
--

DROP TABLE IF EXISTS `session`;
CREATE TABLE IF NOT EXISTS `session` (
  `idSees` int(50) NOT NULL,
  `date_deb` varchar(50) NOT NULL,
  `nbre_jours` int(50) NOT NULL,
  `module` varchar(50) NOT NULL,
  `idSal` int(50) NOT NULL,
  `lieuForm` varchar(50) NOT NULL,
  PRIMARY KEY (`idSees`),
  KEY `idSal` (`idSal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `session`
--

INSERT INTO `session` (`idSees`, `date_deb`, `nbre_jours`, `module`, `idSal`, `lieuForm`) VALUES
(10, '10 mai ', 10, 'module', 653, 'paris');
