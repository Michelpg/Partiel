
-- --------------------------------------------------------

--
-- Structure de la table `salarie`
--

DROP TABLE IF EXISTS `salarie`;
CREATE TABLE IF NOT EXISTS `salarie` (
  `idSal` int(50) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `age` int(10) NOT NULL,
  `fonction` varchar(50) NOT NULL,
  `service` varchar(50) NOT NULL,
  `grade` varchar(50) NOT NULL,
  PRIMARY KEY (`idSal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `salarie`
--

INSERT INTO `salarie` (`idSal`, `nom`, `prenom`, `age`, `fonction`, `service`, `grade`) VALUES
(653, 'VERIN', 'Pierre', 34, 'chef equipe', 'informatique', 'chef');
